<template>
  <div class="notifications__container">
    <h1>공지사항</h1>
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped>
.notifications__container {
  width: 100%;
  height: 100%;
  background-color:aquamarine;
}
</style>