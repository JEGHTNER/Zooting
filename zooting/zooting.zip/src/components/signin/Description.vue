<script setup lang="ts"></script>

<template>
  <div class="flex justify-center p-8">
    <img src="@/assets/images/logo/logo_lg.png" alt="">
  </div>
</template>

<style scoped></style>
