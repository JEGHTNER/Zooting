<script setup lang="ts"></script>

<template>
  <video controls autoplay muted loop class="w-full h-full">
    <!-- Specify the path to your local video file -->
    <source src="@/assets/videos/tutorial_video.mp4" type="video/mp4" />
    비디오 지원이 안돼요ㅠ
  </video>
</template>

<style scoped></style>
