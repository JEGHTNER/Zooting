<template>
    <div class="signup-container">
        <InfoInput/>
    </div>
</template>

<script setup lang="ts">
import InfoInput from '@/components/signup/InfoInput.vue'
</script>

<style scoped>
.signup-container {
    @apply flex flex-col lg:h-screen w-full p-6;
    overflow-y: auto;
}
</style>