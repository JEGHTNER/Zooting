/// <reference types="vite/client" />
interface ImportMeta {
    env: {
        VITE_SERVER_API_URL?: string,
    }
}